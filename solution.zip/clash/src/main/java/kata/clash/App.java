package kata.clash;

import kata.clash.buildings.BlackElixirFactory;
import kata.clash.buildings.BlueTrainingCamp;
import kata.clash.units.Bomber;
import kata.clash.units.Giant;
import kata.clash.units.Miner;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String[] args) throws Exception {
//        System.out.println( "Hello World!" );
//         //reste de la division par 3 : 
//         System.out.println(""+(10%3));
//         //partie entière la division par 3 : 
//         System.out.println(""+(22 / 3));
         
         
        
//        int blueElixir = 400;
//        int gems = 12;
//        System.out.println("(Java 8) \n"
//                + " test et conditions ? avec la valeur a retourner en cas 'true' suivi de ':' \n "
//                + "puis de la valeur à retourner en cas 'false' "
//                + "\n"
//                + ((gems % 2 == 0) && (blueElixir % 500 == 0) ? gems / 2 : gems / 5) * 100
//        );

// //       BlackElixirFactory.ProduceElixir(int gems, int blueElixir);
// System.out.println( BlackElixirFactory.ProduceElixir(1, 100));
        
Bomber bomber= BlueTrainingCamp.ProduceBomber();
Giant giant= BlueTrainingCamp.ProduceGiant();
Miner miner=BlueTrainingCamp.ProduceMiner();


System.out.println(BlackElixirFactory.ProduceElixir(300, 500));        
    }
    
   
}
