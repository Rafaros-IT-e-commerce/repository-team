package kata.clash.units;

import kata.clash.units.actions.MoveInterface;
import kata.clash.units.actions.WalkImplementation;

public abstract class AbstractUnitOfBlueCamp {
	protected int DefensiveHitpoints;
	protected int OffensiveHitpoints;
	
	protected String LastMessage;
	
	//NOTA: on peut mettre optionnellement une implémentation par défaut pour MoveInterface :	
	//protected MoveInterface moveImpl = new WalkImplementation();
	protected MoveInterface moveImpl;
	
	
	public AbstractUnitOfBlueCamp() {		
			}
	
	

	public AbstractUnitOfBlueCamp(int defensiveHitpoints, int offensiveHitpoints, MoveInterface move) {
		super();
		DefensiveHitpoints = defensiveHitpoints;
		OffensiveHitpoints = offensiveHitpoints;
		this.moveImpl = move;
	}
	
	
    public int Move(int seconds)
    {
      return this.moveImpl.move(seconds);
    }
    
    //factorisation du code des getters  & setters :
	public int getDefensiveHitpoints() {
		return DefensiveHitpoints;
	}
	private void setDefensiveHitpoints(int defensiveHitpoints) {
		DefensiveHitpoints = defensiveHitpoints;
	}
	public int getOffensiveHitpoints() {
		return OffensiveHitpoints;
	}
	private void setOffensiveHitpoints(int offensiveHitpoints) {
		OffensiveHitpoints = offensiveHitpoints;
	}
	
	public String ReceiveHit(int attackHitpoints) {
		this.DefensiveHitpoints -= attackHitpoints;

		if (DefensiveHitpoints <= 0) {
			// return cris;
			return this.LastMessage;
		}
		return null;
	}



	public String getLastMessage() {
		return LastMessage;
	}



	public void setLastMessage(String lastMessage) {
		LastMessage = lastMessage;
	}



	public MoveInterface getMoveImpl() {
		return moveImpl;
	}


	/* On pourra utiliser le  setter ci-dessous associé à l'implémentation de "MoveInterface" pour choisir 
	 * à la volée un comportement de déplacement
	 * @param moveImpl
	 */
	public void setMoveImpl(MoveInterface moveImpl) {
		this.moveImpl = moveImpl;
	}
	
	

}
