package kata.clash.units;

public class Unit {
	protected int DefensiveHitpoints;
	protected int OffensiveHitpoints;
	private String cris;
	private int map;
	
	public int getDefensiveHitpoints() {
		return DefensiveHitpoints;
	}
	private void setDefensiveHitpoints(int defensiveHitpoints) {
		DefensiveHitpoints = defensiveHitpoints;
	}
	public int getOffensiveHitpoints() {
		return OffensiveHitpoints;
	}
	private void setOffensiveHitpoints(int offensiveHitpoints) {
		OffensiveHitpoints = offensiveHitpoints;
	}
	
    public String ReceiveHit(int attackHitpoints)
    {
    	DefensiveHitpoints -= attackHitpoints;
    	
    	if( DefensiveHitpoints <= 0)
    	{
    		//return cris;
    		//if(attackHitpoints >= 10000 )
        	return "I WILL RISE AGAIN FROM THE ASHES";
    	}
        return cris;
    }
    
    public int Move(int seconds)
    {
    	return seconds*map;
      
    }
    public String getCris() {
		return cris;
	}
    public void setCris(String cris) {
		this.cris = cris;
	}
	public int getMap() {
		return map;
	}
	public void setMap(int map) {
		this.map = map;
	}
}
