package kata.clash.units;

import kata.clash.units.actions.TunnelUnderImplementation;

public class Miner extends AbstractUnitOfBlueCamp  {
/*	private int DefensiveHitpoints;
	private int OffensiveHitpoints;*/
	
	
	/**Constructeur*/
	public Miner() {
		super();
		this.DefensiveHitpoints = 800;
		this.OffensiveHitpoints = 1200;
		this.LastMessage="we return in the ground";
		// injection de la méthode de déplacement "move" via le constructeur :
		this.moveImpl=new TunnelUnderImplementation();
	}
	
	
	
/*	public int getDefensiveHitpoints() {
		return DefensiveHitpoints;
	}

	private void setDefensiveHitpoints(int defensiveHitpoints) {
		DefensiveHitpoints = defensiveHitpoints;
	}
	public int getOffensiveHitpoints() {
		return OffensiveHitpoints;
	}
	private void setOffensiveHitpoints(int offensiveHitpoints) {
		OffensiveHitpoints = offensiveHitpoints;
	}

	
	public String ReceiveHit(int attackHitpoints) {
		this.DefensiveHitpoints -= attackHitpoints;

		if (DefensiveHitpoints <= 0) {
			// return cris;
			return "we return in the ground";
		}
		return null;
	}
*/	
    
//    public int Move(int seconds)
//    {
//      throw new UnsupportedOperationException();
//    }

	
}
