package kata.clash.units;

import kata.clash.units.actions.TunnelUnderImplementation;
import kata.clash.units.actions.WalkImplementation;

public class Giant extends AbstractUnitOfBlueCamp {
	/*
	 * private int DefensiveHitpoints; private int OffensiveHitpoints;
	 */

	/** Constructeur **/
	public Giant() {
		super();
		this.DefensiveHitpoints = 4500;
		this.OffensiveHitpoints = 3000;
		// injection de la méthode de déplacement "move" via le constructeur :
		this.moveImpl = new WalkImplementation();
		this.LastMessage="OUR IRON FISTS WILL BE REMEMBERED FOREVER";
	}

/*	public int getDefensiveHitpoints() {
		return DefensiveHitpoints;
	}

	private void setDefensiveHitpoints(int defensiveHitpoints) {
		DefensiveHitpoints = defensiveHitpoints;
	}

	public int getOffensiveHitpoints() {
		return OffensiveHitpoints;
	}

	private void setOffensiveHitpoints(int offensiveHitpoints) {
		OffensiveHitpoints = offensiveHitpoints;
	}

	public String ReceiveHit(int attackHitpoints) {
		this.DefensiveHitpoints -= attackHitpoints;

		if (DefensiveHitpoints <= 0) {
			// return cris;
			return this.LastMessage;
		}
		return null;
	}
*/
/*	public int Move(int seconds) {
		throw new UnsupportedOperationException();
	}*/

}
