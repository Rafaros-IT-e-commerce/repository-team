package kata.clash.exceptions;

public class DwarfsAngryException extends Exception {
	
	public DwarfsAngryException() {
		super("You must be joking, we can not work so cheap !!!!");
	}

}
