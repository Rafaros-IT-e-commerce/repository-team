package kata.clash.exceptions;

public class OverflowingQuantityException extends Exception {
	
	public OverflowingQuantityException() {
		super("Grrrrr, you are too greedy !!!!");
	}

}