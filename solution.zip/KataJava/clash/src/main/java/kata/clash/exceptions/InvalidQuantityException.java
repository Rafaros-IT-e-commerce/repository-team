package kata.clash.exceptions;

public class InvalidQuantityException extends Exception {
	
	public InvalidQuantityException() {
		super("ARGHHHHH !!! We told you we do not like computations.Provide us the exact quantities");
	}

}
