package kata.clash.units;

public enum UnitType {
    BOMBER,
    DRAGON,
    GIANT,
    MINER
}
