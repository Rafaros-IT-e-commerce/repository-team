package kata.clash.units.actions;

public class FlyImplementation implements MoveInterface {

	public int move(int seconds) {
		// TODO Auto-generated method stub
		return seconds*8;
	}



}