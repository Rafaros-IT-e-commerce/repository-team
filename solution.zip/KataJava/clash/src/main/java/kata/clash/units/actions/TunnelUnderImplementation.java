package kata.clash.units.actions;

public class TunnelUnderImplementation implements MoveInterface {

	public int move(int seconds) {
		// TODO Auto-generated method stub
		return seconds*5;
	}



}