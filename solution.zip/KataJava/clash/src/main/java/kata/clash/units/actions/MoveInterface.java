package kata.clash.units.actions;

public interface MoveInterface {
	
	/**signature / 100% abstrait ***/
	public int move(int seconds);

}
