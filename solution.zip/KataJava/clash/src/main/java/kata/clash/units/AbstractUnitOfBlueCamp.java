package kata.clash.units;

import kata.clash.units.actions.MoveInterface;
import kata.clash.units.actions.WalkImplementation;

public abstract class AbstractUnitOfBlueCamp {
	protected int DefensiveHitpoints;
	protected int OffensiveHitpoints;
	
	//NOTA: on peut mettre optionnellement une implémentation par défaut pour MoveInterface :	
	//protected MoveInterface moveImpl = new WalkImplementation();
	protected MoveInterface moveImpl;
	
	public AbstractUnitOfBlueCamp() {		
			}

	public AbstractUnitOfBlueCamp(int defensiveHitpoints, int offensiveHitpoints, MoveInterface move) {
		super();
		DefensiveHitpoints = defensiveHitpoints;
		OffensiveHitpoints = offensiveHitpoints;
		this.moveImpl = move;
	}
	
    public int Move(int seconds)
    {
      return this.moveImpl.move(seconds);
    }

}
