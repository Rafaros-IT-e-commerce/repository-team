package kata.clash.units;

import kata.clash.units.actions.RunImplementation;
import kata.clash.units.actions.TunnelUnderImplementation;
import kata.clash.units.actions.WalkImplementation;

public class Bomber extends AbstractUnitOfBlueCamp {
/*	private int DefensiveHitpoints;
	private int OffensiveHitpoints;*/
	
	
	/**Constructeur*/
	public Bomber() {
		super();
		this.DefensiveHitpoints = 350;
		this.OffensiveHitpoints = 800;
		// injection de la méthode de déplacement "move" via le constructeur (Ex2):
		//this.moveImpl=new WalkImplementation();
		
		//implémentation pour Ex3 :
		this.moveImpl=new RunImplementation();
	}
	
	public int getDefensiveHitpoints() {
		return DefensiveHitpoints;
	}
	private void setDefensiveHitpoints(int defensiveHitpoints) {
		DefensiveHitpoints = defensiveHitpoints;
	}
	public int getOffensiveHitpoints() {
		return OffensiveHitpoints;
	}
	private void setOffensiveHitpoints(int offensiveHitpoints) {
		OffensiveHitpoints = offensiveHitpoints;
	}

	public String ReceiveHit(int attackHitpoints) {

		this.DefensiveHitpoints -= attackHitpoints;

		if (DefensiveHitpoints <= 0) {
			// return cris;
			return "WHEN YOU play with Explosives it is a dangerous bussiness";
		}
		return null;
	}
  

	//méthode déjà définie dans la SuperClasse :
/*    public int Move(int seconds)
    {
      throw new UnsupportedOperationException();
    }*/

	
}
